const CONFIG = {
    user: {
        name: 'Alex Kim',
        email: 'alex.k@example.com',
        initials: 'AK'
    }
};